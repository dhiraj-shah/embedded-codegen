from dataclasses import dataclass
from typing import Any, List

class ASTNode:
    """Base class for all AST nodes."""
    pass

@dataclass
class ASTModule(ASTNode):
    """Holds the top-level functions in the module."""
    functions: List["ASTFunction"]

@dataclass
class ASTFunction(ASTNode):
    """A function declaration: name, parameters, and a list of statements."""
    name: str
    params: List[str]
    body: List["ASTStmt"]

class ASTStmt(ASTNode):
    """Base class for statements."""
    pass

@dataclass
class ASTCall(ASTStmt):
    """Represents a call to an extern function (e.g. gpio_init())."""
    func_name: str
    args: List[Any]

