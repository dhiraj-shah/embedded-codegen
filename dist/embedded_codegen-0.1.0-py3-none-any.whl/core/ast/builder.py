from core.config import BoardConfig
from core.ast.nodes import ASTModule, ASTFunction, ASTCall

def build_ast(cfg: BoardConfig) -> ASTModule:
    """
    Build a very simple AST: a single `main` function that
    calls init routines for any enabled peripherals.
    """
    stmts = []
    if cfg.gpio:
        stmts.append(ASTCall("gpio_init", []))
    if cfg.uart:
        stmts.append(ASTCall("uart_init", []))
    if cfg.timer:
        stmts.append(ASTCall("timer_init", []))

    main_fn = ASTFunction(name="main", params=[], body=stmts)
    return ASTModule(functions=[main_fn])

