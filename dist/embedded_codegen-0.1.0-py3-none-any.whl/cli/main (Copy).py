#!/usr/bin/env python3
import sys
import logging
import json
from pathlib import Path

import yaml
import typer

from core.config import load_config
from core.generator import CodeGenerator

app = typer.Typer(help="Embedded Peripheral Code Generator")

@app.command("generate")
def generate(
    config: Path = typer.Option(..., "--config", help="Path to YAML board config"),
    template_dir: Path = typer.Option(Path("templates"), "--template-dir", help="Template directory"),
    out_dir: Path = typer.Option(Path("out"), "--out-dir", help="Output directory"),
    target: str = typer.Option(..., "--target", case_sensitive=False,
        help="Target platform {x86, imx7, stm32}"),
    emit_ast: Path = typer.Option(None, "--emit-ast", help="Dump AST to JSON"),
    emit_ir: Path = typer.Option(None, "--emit-ir", help="Dump LLVM IR to file"),
    emit_obj: Path = typer.Option(None, "--emit-obj", help="Emit object file"),
    llvm_ir_flag: bool = typer.Option(False, "--llvm-ir", help="Use LLVM IR pipeline"),
    verbose: int = typer.Option(0, "-v", "--verbose", help="Increase verbosity", count=True),
):
    # logging setup
    level = logging.WARNING
    if verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s"
    )
    log = logging.getLogger("embedded-codegen")
    log.debug("CLI args: %r", {
        'config': config, 'template_dir': template_dir, 'out_dir': out_dir,
        'target': target, 'emit_ast': emit_ast, 'emit_ir': emit_ir,
        'emit_obj': emit_obj, 'llvm_ir': llvm_ir_flag, 'verbose': verbose,
    })

    # target and config maps
    TRIPLES = {
        "x86":   "x86_64-pc-linux-gnu",
        "imx7":  "aarch64-none-linux-gnu",
        "stm32": "armv7-none-eabi",
    }
    TARGET_CONFIG = {
        "x86":   {"cpu": "x86-64",    "features": ""},
        "imx7":  {"cpu": "generic",   "features": ""},
        "stm32": {"cpu": "cortex-m3", "features": "+thumb2"},
    }

    if target not in TRIPLES:
        log.critical("Invalid target '%s', must be one of %s", target, list(TRIPLES.keys()))
        raise typer.Exit(code=1)

    # load config
    try:
        cfg = load_config(config)
    except Exception as e:
        log.critical("Failed loading config: %s", e)
        raise typer.Exit(code=1)
    log.info(
        "Loaded board config: %s (GPIO=%d, UART=%d, TIMER=%d)",
        cfg.name, len(cfg.gpio), len(cfg.uart), len(cfg.timer)
    )

    # IR / AST flow
    if llvm_ir_flag or emit_ast or emit_ir or emit_obj:
        from core.ast.builder import build_ast
        from core.ir.codegen import ast_to_llvm_ir
        from core.ir.backend import init_llvm, compile_module

        ast = build_ast(cfg)
        if emit_ast:
            Path(emit_ast).write_text(json.dumps(ast, default=lambda o: o.__dict__, indent=2))
            log.info("AST written to %s", emit_ast)
            raise typer.Exit()

        llvm_mod = ast_to_llvm_ir(ast, cfg.name)
        ir_text = str(llvm_mod)
        if emit_ir:
            Path(emit_ir).write_text(ir_text)
            log.info("LLVM IR written to %s", emit_ir)
            raise typer.Exit()

        if emit_obj:
            init_llvm()
            try:
                obj = compile_module(
                    ir_text,
                    target_triple=TRIPLES[target],
                    cpu=TARGET_CONFIG[target]["cpu"],
                    features=TARGET_CONFIG[target]["features"],
                )
            except Exception as e:
                log.critical("Failed to compile object: %s", e)
                raise typer.Exit(code=1)
            Path(emit_obj).write_bytes(obj)
            log.info("Object file emitted to %s", emit_obj)
            raise typer.Exit()

    # fallback C generator
    try:
        cg = CodeGenerator(cfg, template_dir, out_dir, target)
        cg.generate(llvm_ir=llvm_ir_flag)
    except Exception as e:
        log.critical("Code generation failed: %s", e)
        raise typer.Exit(code=1)

# entrypoint
if __name__ == "__main__":
    app()

